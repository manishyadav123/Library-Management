#include<bits/stdc++.h>
//#include<iomanio.h>
#include<process.h>
using namespace std;

class book
{
     char bno[6];
	 char bname[50];
	 char aname[20];
	 
	public:
	 
	 void create_book()
	 {
	     cout<<"\n New Book Entry....\n";
		 cout<<"\n Enter The Book no.";
		 cin>>bno; 	
		 cout<<"\n\n Enter The Name Of The Book";
	     gets(bname);   
	     cout<<"\n\n Enter The Author's Name ";
	     gets(aname);
	     cout<<"\n\n\nBook Created";
	 }	
	 void show_book()
	 {
	 	cout<<"\nBook no. :"<<bno;
	 	cout<<"\nBook Name :";
	 	cout<<bname;
	 	cout<<"Author Name : ";
	 	cout<<aname;
	 }
	 char* retbno()
	 {
	 	 return bno;
	 }
	 void report()
	 {
	 	cout<<endl<<bno<<"           "<<bname<<"          "<<aname<<endl;
	 }
};   //class ends here


class student
{
     char admno[6];
	 char name[20];
	 char stbno[6];
	 int token;
	 
	public:
	  
	  void create_student()	
	  {
	  	  cout<<"\n New Student Entry...\n";
	  	  cout<<"\n Enter the admission no.";
	      cin>>admno;
	      cout<<"\n\n Enter the Name of The Student.";
	      cin>>name;
	      token=0;
	      stbno[0]='/0';
	      cout<<"\n\n Student Record Created..";
	  }
	  void show_student()
	  {
	  	 cout<<"\nAdmission no. :"<<admno;
	  	 cout<<"\nStudent Name :";
	  	 cout<<name;
	  	 cout<<"\nNo of book issued :"<<token;
	  	 if(token==1)
	  	   cout<<"\nBook No "<<stbno;
	  }
	  char* retadmno()
	  {
	  	return admno;
	  }
	  char* retstbno()
	  {
	  	return stbno;;
	  }
	  int rettoken()
	  {
	  	return token; 
	  }
	  void addtoken()
	  {
	  	 token=1;
	  }
	  void resettoken()
	  {
	  	 token=0;
	  }
	  void getstbno(char t[])
	  {
	  	strcpy(stbno,t);
	  }
	  void report()
	  {
	  	cout<<"\t"<<admno<<setw(20)<<name<<setw(10)<<token<<endl;
	  }
};


    fstream fp,fp1;
    book bk;
    student st;
    
    void write_book()
    {
    	char ch;
    	fp.open("book.dat",ios::out|ios::app);
    	do{
    		  bk.create_book();
    		  fp.write((char*)&bk,sizeof(book));
    		  cout<<"\n\nDo you want to add more record..(y/n?)";
    		  cin>>ch;
		}while(ch=='y'||ch=='Y');
		fp.close();
	}
    
    void write_student()
    {
    	char ch;
    	fp.open("student.dat",ios::out|ios::app);
    	do{
    		  st.create_student();
    		  fp.write((char*)&st,sizeof(student));
    		  cout<<"\n\ndo you want to add more records...(y/n?)";
		      cin>>ch;   
		}while(ch=='y'||ch=='Y');
		fp.close();
	}
	
	void display_spb(char n[])
	{
		cout<<"\nBOOK Details\n";
		int flag=0;
		fp.open("book.dat",ios::in);
		while(fp.read((char*)&bk,sizeof(book)))
		{
			if(strcmpi(bk.retbno(),n)==0)
			{
				bk.show_book();
				flag=1;
			}
		}
		fp.close();
		if(flag==0)
		     cout<<"\n\nBook does not exists";    
	}
	void display_sps(char n[])
	{
		cout<<"\nStudent Details\n";
		int flag=0;
		fp.open("student.dat",ios::in);
		while(fp.read((char*)&st,sizeof(student)))
		{
			if((strcmpi(st.retadmno(),n)==0))
			{
				st.show_student();
				flag=1;
			}
		}
		fp.close();
		if(flag==0)
		  cout<<"\n\nStudent does not exists";  
	}
	
	//   function to display all students details
	
	void display_alls()
	{
		fp.open("student.dat",ios::in);
		if(!fp)
		{
			cout<<"ERROR!!!File could not be found";
		  return;	
		}
		
		cout<<"\n\n\t\tStudent List\n\n";
		cout<<"======================================================================\n";
		cout<<"\tAdmission No."<<setw(10)<<"Name"<<setw(20)<<"Book Issued\n";
		cout<<"======================================================================\n";
	    while(fp.read((char*)&st,sizeof(student)))
	    {
	    	 st.report(); 
		}
		fp.close();
	}
	
	
	//  function to display books list
	
	void display_allb()
	{
		fp.open("book.dat",ios::in);
		if(!fp)
		{
			cout<<"ERROR!!! File could not be open ";
			//getch();
			  return;
		}
	cout<<"\n\n\tBook List\n\n";
	
	cout<<"=============================================\n";
    
	cout<<"BOOK NUMBER"<<setw(20)<<"BOOK NAME"<<setw(25)<<"AUTHOR";
	while(fp.read((char*)&bk,sizeof(book)))
    {
    	 bk.report();
	}
	   fp.close();
	}
	
	
	//function to issue book
	
	void book_issue()
	{
		char sn[6],bn[6];
		int found=0,flag=0;
		cout<<"\n\nBook Issue...";
		cout<<"\n\n\tEnter The student's admission no.";
	   // gets(sn);
	    //fp.open("student.dat",ios::in|ios::out);
	    cin>>sn;
	    fp.open("student.dat",ios::in|ios::out);
	      fp1.open("book.dat",ios::in|ios::out);
	      while(fp.read((char*)&st,sizeof(student))&&found==0)
	      {
	      	if(strcmpi(st.retadmno(),sn)==0)
	      	{
	      		found=1;
	      		if(st.rettoken()==0)
	      		{
	      			cout<<"\n\n\tEnter the book no.";
	      			cin>>bn;
	      			while(fp1.read((char*)&bk,sizeof(book)) && flag==0)
	      			{
	      				 if(strcmpi(bk.retbno(),bn)==0)
						   {
						   	     bk.show_book();
						   	     flag=1;
						   	     st.addtoken();
						   	     st.getstbno(bk.retbno());
						   	     int pos=-1*sizeof(st);
						   	     fp.seekp(pos,ios::cur);
						   	     fp.write((char*)&st,sizeof(student));
						   	     cout<<"\n\n\tBook issued successfully\n\nPlease Note:Write the current date in backside of your book and submit within 15 days fine Rs.1 for each day period";
							} 
					}
					 if(flag==0)
					    cout<<"Book no does not exists";
				  }
				  else
				     cout<<"You have not returned the last book";
			  }
		  }
		  if(found==0)
		      cout<<"Student record not exist...";
		  fp.close();
		  fp1.close();    
	}
	
	
	void book_deposit()
	{
		char sn[6],bn[6];
		int found=0,flag=0,day,fine;
		cout<<"\n\nBook Deposit ...";
		cout<<"\n\n\tEnter the student's admission no";
		cin>>sn;
		fp.open("student.dat",ios::in|ios::out);
	    fp1.open("book.dat",ios::in|ios::out);
	    while(fp.read((char*)&st,sizeof(student))&&found==0)
	    {
	    	if(strcmpi(st.retadmno(),sn)==0)
	    	{
	    		found==1;
	    		if(st.rettoken()==1)
	    		{
	    			while(fp1.read((char*)&bk,sizeof(book))&&flag==0)
				    {
				    	if(strcmpi(bk.retbno(),st.retstbno())==0)
					    {
					    	bk.show_book();
					    	flag=1;
					    	cout<<"\n\nBook deposited in no of days";
					    	cin>>day;
					    	if(day>15)
					    	{
					    		fine=(day-15)*1;
					    		cout<<"\n\nFine has to be deposited Rs. "<<fine;
							}
							st.resettoken();
							int pos=-1*sizeof(st);
							fp.seekp(pos,ios::cur);
							fp.write((char*)&st,sizeof(student));
							cout<<"\n\n\tBook deposited successfully";
						}
					}
					if(flag==0)
					   cout<<"book no does not exists";
				}
				else
				   cout<<"No book is issued..please check!!";
			}
		}
		if(found==0)
		  cout<<"Student record not exists...";
		  fp.close();
		  fp1.close();
	}
		
	// Administration menu function
	
	void admin_menu()
	{
		int ch2;
		cout<<"\n\n\n\t\tADMINISTRATOR MENU";
		cout<<"\n\t1.Create Student Record";
		cout<<"\n\t2.Dispplay ALL STUDENTS RECORDS";
	 	cout<<"\n\t3.Dispplay SPECIFIC STUDENT RECORDS";
	    cout<<"\n\t4.Create BOOK";
	    cout<<"\n\t5.Display all BOOKs";
	    cout<<"\n\t6.Display specific BOOKs";
	    cout<<"\n\t7.Please Enter Your Choice(1-7)";
	    cin>>ch2;
	    switch(ch2)
	    {
	    	case 1:write_student();
	    	break;
	    	case 2:display_alls();
	    	break;
	    	case 3:char num[6];
	    	       cout<<"\n\n\tPlease Enter the Admission No. ";
	    	       cin>>num;
	    	       display_sps(num);
	    	       break;
	    	case 4:write_book();
			break;
			case 5:display_allb();
			break;
			case 6:num[6];
			cout<<"\n\n\tPlease Enter The Book Number.";
			cin>>num;
			display_spb(num);
			break;
			case 7:return;
			default:cout<<"\a";	
		}
		admin_menu();
	}
	
	//  void Intro
	
	void intro()
	{
		cout<<"                                                   YMCA UST                          "<<endl<<endl;
        cout<<"                                                 Library mgmt                        "<<endl<<endl;
 		cout<<"                                                   WELCOME                           "<<endl<<endl;
 		cout<<"                                           Created By-Yadav Manish                           "<<endl<<endl;
		 cout<<"press any key to continue...";
	}
	
	//      main function
	
	
	int main()
	{
		char ch;
		intro();
		do{
		cout<<"\n\n\n\tMain Menu";
		cout<<"\n\n\t01.BOOK ISSUE";
		cout<<"\n\n\t02.BOOK DEPOSIT";
		cout<<"\n\n\t03.ADMINISTRATOR MENU";
		cout<<"\n\n\t04.EXIT";
		cout<<"\n\n\tPlease Select Your Option(1-4)";
		cin>>ch;
		switch(ch)
		{
		  case '1':book_issue();
		           break;	
		  case '2':book_deposit();
		           break;
		  case '3':admin_menu();
		           break;
		  case '4':exit(0);
		           break;
				   
		  default:cout<<"\a";		   		   		   	
		 }	 
		}while(ch!='4');
	}
